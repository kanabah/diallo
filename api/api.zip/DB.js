module.exports = {
    DB: `mongodb+srv://madiou:madiou@cluster0-truva.mongodb.net/test?retryWrites=true&w=majority`,
    DBDEV: 'mongodb://localhost:27017/abf'
};